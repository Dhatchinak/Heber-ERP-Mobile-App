import 'package:bhc_erp/Student/screens/main_page.dart';
import 'package:bhc_erp/core/auth/user_type.dart';
import 'package:bhc_erp/Staff/theme_provider.dart'; // ← ADD
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/auth/auth_provider.dart';
import 'core/theme/app_theme.dart';
import 'login/screens/unified_login_screen.dart';
import 'staff/screens/staff_dashboard.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final authProvider = AuthProvider();
  await authProvider.init();
  runApp(MyApp(authProvider: authProvider));
}

class MyApp extends StatelessWidget {
  final AuthProvider authProvider;
  const MyApp({super.key, required this.authProvider});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: authProvider),
        ChangeNotifierProvider(create: (_) => AppThemeProvider()),
        ChangeNotifierProvider(create: (_) => StaffThemeProvider()), // ← ADD
      ],
      child: Consumer2<AuthProvider, AppThemeProvider>(
        builder: (context, auth, theme, _) {
          return MaterialApp(
            title: 'BHC Unified ERP',
            debugShowCheckedModeBanner: false,
            theme: theme.themeData,
            home: _getInitialRoute(auth),
            routes: {
              '/login': (context) => const UnifiedLoginScreen(),
              '/staff-dashboard': (context) => const StaffDashboard(),
              '/student-dashboard': (context) => const MainPage(
                    rollNo: '',
                    studentName: '',
                  ),
            },
          );
        },
      ),
    );
  }

  Widget _getInitialRoute(AuthProvider auth) {
    if (auth.isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (!auth.isAuthenticated) {
      return const UnifiedLoginScreen();
    }
    if (auth.userType == UserType.student) {
      return MainPage(
        rollNo: auth.studentRollNo ?? '',
        studentName: auth.studentName ?? 'Student',
      );
    }
    return const StaffDashboard();
  }
}