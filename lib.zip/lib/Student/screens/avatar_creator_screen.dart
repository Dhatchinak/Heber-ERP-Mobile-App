import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:bhc_erp/Student/theme_provider.dart';
import 'package:bhc_erp/Student/services/avatar_service.dart';
import 'package:bhc_erp/Student/widgets/avatar_painter.dart';

// No path import here - that was causing the conflict!

// ─── Enhanced Color Matrix Presets ──────────────────────────────
ColorFilter enhancedAvatarColorFilter(int filterIndex) {
  switch (filterIndex) {
    case 1: // Cartoon Pop
      return const ColorFilter.matrix([
        1.6,
        -0.2,
        -0.1,
        0,
        -8,
        -0.1,
        1.6,
        -0.1,
        0,
        -8,
        -0.1,
        -0.2,
        1.6,
        0,
        -8,
        0,
        0,
        0,
        1.2,
        0,
      ]);
    case 2: // Pencil Sketch
      return const ColorFilter.matrix([
        1.8,
        1.8,
        1.8,
        0,
        -220,
        1.8,
        1.8,
        1.8,
        0,
        -220,
        1.8,
        1.8,
        1.8,
        0,
        -220,
        0,
        0,
        0,
        1,
        0,
      ]);
    case 3: // Anime Cel
      return const ColorFilter.matrix([
        1.3,
        0.1,
        0,
        0,
        12,
        0,
        1.25,
        0.05,
        0,
        8,
        0.05,
        0,
        1.2,
        0,
        5,
        0,
        0,
        0,
        1.1,
        0,
      ]);
    case 4: // Watercolor
      return const ColorFilter.matrix([
        1.1,
        0.05,
        0.05,
        0,
        18,
        0.05,
        1.08,
        0.05,
        0,
        15,
        0.05,
        0.05,
        1.12,
        0,
        20,
        0,
        0,
        0,
        0.95,
        0,
      ]);
    case 5: // Comic Book
      return const ColorFilter.matrix([
        1.5,
        -0.1,
        -0.2,
        0,
        -10,
        -0.1,
        1.4,
        -0.1,
        0,
        -5,
        -0.2,
        -0.1,
        1.3,
        0,
        -15,
        0,
        0,
        0,
        1.3,
        0,
      ]);
    case 6: // Oil Painting
      return const ColorFilter.matrix([
        1.2,
        0.08,
        0.02,
        0,
        8,
        0.05,
        1.18,
        0.05,
        0,
        6,
        0.02,
        0.08,
        1.15,
        0,
        4,
        0,
        0,
        0,
        1.05,
        0,
      ]);
    case 7: // Charcoal
      return const ColorFilter.matrix([
        1.2,
        1.2,
        1.2,
        0,
        -180,
        1.2,
        1.2,
        1.2,
        0,
        -180,
        1.2,
        1.2,
        1.2,
        0,
        -180,
        0,
        0,
        0,
        1,
        0,
      ]);
    case 8: // Pastel Dream
      return const ColorFilter.matrix([
        1.05,
        0.12,
        0.08,
        0,
        22,
        0.1,
        1.02,
        0.13,
        0,
        18,
        0.08,
        0.1,
        1.0,
        0,
        25,
        0,
        0,
        0,
        0.98,
        0,
      ]);
    case 9: // Neon Glow
      return const ColorFilter.matrix([
        1.7,
        -0.15,
        -0.1,
        0,
        5,
        -0.05,
        1.5,
        -0.05,
        0,
        -2,
        -0.1,
        -0.05,
        1.8,
        0,
        10,
        0,
        0,
        0,
        1.2,
        0,
      ]);
    default: // Original
      return const ColorFilter.matrix([
        1,
        0,
        0,
        0,
        0,
        0,
        1,
        0,
        0,
        0,
        0,
        0,
        1,
        0,
        0,
        0,
        0,
        0,
        1,
        0,
      ]);
  }
}

// ─── Enhanced Filter Info ──────────────────────────────────────
const List<Map<String, dynamic>> enhancedFilters = [
  {
    'name': 'Original',
    'emoji': '📸',
    'desc': 'Your authentic photo',
    'index': 0
  },
  {
    'name': 'Cartoon Pop',
    'emoji': '🎭',
    'desc': 'Cell-shaded, vibrant comic style',
    'index': 1
  },
  {
    'name': 'Pencil Sketch',
    'emoji': '✏️',
    'desc': 'Hand-drawn pencil art effect',
    'index': 2
  },
  {
    'name': 'Anime Cel',
    'emoji': '🌸',
    'desc': 'Bright anime-style coloring',
    'index': 3
  },
  {
    'name': 'Watercolor',
    'emoji': '🎨',
    'desc': 'Soft, dreamy artistic wash',
    'index': 4
  },
  {
    'name': 'Comic Book',
    'emoji': '📚',
    'desc': 'Halftone-inspired pop art',
    'index': 5
  },
  {
    'name': 'Oil Painting',
    'emoji': '🖼️',
    'desc': 'Rich textured classic look',
    'index': 6
  },
  {
    'name': 'Charcoal',
    'emoji': '⚫',
    'desc': 'Dark dramatic sketch',
    'index': 7
  },
  {
    'name': 'Pastel Dream',
    'emoji': '💫',
    'desc': 'Soft romantic tones',
    'index': 8
  },
  {
    'name': 'Neon Glow',
    'emoji': '🌈',
    'desc': 'Cyberpunk electric style',
    'index': 9
  },
];

// ─── Enhanced Sticker Collection ──────────────────────────────
const List<Map<String, dynamic>> enhancedStickers = [
  {'emoji': '—', 'name': 'None', 'color': 0xFF6B7280},
  {'emoji': '⭐', 'name': 'Star', 'color': 0xFFF59E0B},
  {'emoji': '🔥', 'name': 'Fire', 'color': 0xFFEF4444},
  {'emoji': '💯', 'name': 'Perfect', 'color': 0xFF10B981},
  {'emoji': '🎓', 'name': 'Graduate', 'color': 0xFF6366F1},
  {'emoji': '👑', 'name': 'Royal', 'color': 0xFFD4AF37},
  {'emoji': '✨', 'name': 'Sparkle', 'color': 0xFFFBBF24},
  {'emoji': '🚀', 'name': 'Rocket', 'color': 0xFF3B82F6},
  {'emoji': '💪', 'name': 'Strong', 'color': 0xFFF97316},
  {'emoji': '🌟', 'name': 'Glow', 'color': 0xFFFDE047},
];

// ─── Premium Color Palette ────────────────────────────────────
const List<Map<String, dynamic>> premiumBackgrounds = [
  {'hex': '#EEF2FF', 'name': 'Lavender Mist'},
  {'hex': '#FEF3C7', 'name': 'Cream'},
  {'hex': '#ECFDF5', 'name': 'Mint'},
  {'hex': '#FDF2F8', 'name': 'Rose'},
  {'hex': '#E0F2FE', 'name': 'Sky'},
  {'hex': '#F0FDF4', 'name': 'Emerald'},
  {'hex': '#FFF7ED', 'name': 'Orange Blossom'},
  {'hex': '#F5F3FF', 'name': 'Periwinkle'},
  {'hex': '#FAFAFA', 'name': 'Pure White'},
  {'hex': '#1e1b4b', 'name': 'Midnight'},
  {'hex': '#052e16', 'name': 'Forest'},
  {'hex': '#450a0a', 'name': 'Burgundy'},
  {'hex': '#0f172a', 'name': 'Slate'},
  {'hex': '#18181b', 'name': 'Charcoal'},
];

const List<Map<String, dynamic>> premiumAccents = [
  {'hex': '#6366f1', 'name': 'Indigo'},
  {'hex': '#8b5cf6', 'name': 'Violet'},
  {'hex': '#ec4899', 'name': 'Pink'},
  {'hex': '#f43f5e', 'name': 'Rose'},
  {'hex': '#ef4444', 'name': 'Red'},
  {'hex': '#f97316', 'name': 'Orange'},
  {'hex': '#eab308', 'name': 'Yellow'},
  {'hex': '#22c55e', 'name': 'Green'},
  {'hex': '#14b8a6', 'name': 'Teal'},
  {'hex': '#0ea5e9', 'name': 'Sky Blue'},
  {'hex': '#3b82f6', 'name': 'Blue'},
  {'hex': '#a855f7', 'name': 'Purple'},
  {'hex': '#FFD700', 'name': 'Gold'},
  {'hex': '#64748b', 'name': 'Slate Gray'},
  {'hex': '#1a1a1a', 'name': 'Black'},
];

// ─── Main Enhanced Avatar Creator Screen ──────────────────────
class EnhancedAvatarCreatorScreen extends StatefulWidget {
  final String rollNo;
  final AvatarConfig? initial;

  const EnhancedAvatarCreatorScreen({
    super.key,
    required this.rollNo,
    this.initial,
  });

  @override
  State<EnhancedAvatarCreatorScreen> createState() =>
      _EnhancedAvatarCreatorScreenState();
}

class _EnhancedAvatarCreatorScreenState
    extends State<EnhancedAvatarCreatorScreen>
    with SingleTickerProviderStateMixin {
  late AvatarConfig _config;
  late TabController _tabCtrl;
  bool _saving = false;
  bool _picking = false;

  final _tabs = const [
    Tab(icon: Icon(Icons.filter_vintage_rounded, size: 20), text: 'Filter'),
    Tab(icon: Icon(Icons.circle_outlined, size: 20), text: 'Frame'),
    Tab(icon: Icon(Icons.palette_rounded, size: 20), text: 'Colors'),
    Tab(icon: Icon(Icons.emoji_emotions_rounded, size: 20), text: 'Sticker'),
  ];

  @override
  void initState() {
    super.initState();
    _config = widget.initial ?? const AvatarConfig();
    _tabCtrl = TabController(length: _tabs.length, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto(ImageSource source) async {
    if (_picking) return;
    setState(() => _picking = true);
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(
        source: source,
        maxWidth: 1080,
        maxHeight: 1080,
        imageQuality: 90,
      );
      if (picked == null || !mounted) return;

      if (mounted) {
        setState(() => _config = _config.copyWith(photoPath: picked.path));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    await AvatarService.save(widget.rollNo, _config);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Row(
            children: [
              Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 20),
              SizedBox(width: 12),
              Text('Avatar saved!',
                  style: TextStyle(fontWeight: FontWeight.w600)),
            ],
          ),
          backgroundColor: Color(0xFF10B981),
          behavior: SnackBarBehavior.floating,
          duration: Duration(seconds: 2),
        ),
      );
      Navigator.pop(context, _config);
    }
    setState(() => _saving = false);
  }

  @override
  Widget build(BuildContext context) {
    final c = Provider.of<ThemeProvider>(context);
    return Scaffold(
      backgroundColor: c.bg,
      appBar: _buildAppBar(c),
      body: Column(
        children: [
          _buildHeroSection(c),
          Container(
            color: c.surface,
            child: TabBar(
              controller: _tabCtrl,
              tabs: _tabs,
              labelColor: c.violet,
              unselectedLabelColor: c.textMid,
              indicatorColor: c.violet,
              indicatorSize: TabBarIndicatorSize.label,
              indicatorWeight: 3,
              labelStyle:
                  const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
              unselectedLabelStyle:
                  const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabCtrl,
              children: [
                _FilterTab(
                    config: _config,
                    onChanged: (v) => setState(() => _config = v)),
                _FrameTab(
                    config: _config,
                    onChanged: (v) => setState(() => _config = v)),
                _ColorsTab(
                    config: _config,
                    onChanged: (v) => setState(() => _config = v)),
                _StickerTab(
                    config: _config,
                    onChanged: (v) => setState(() => _config = v)),
              ],
            ),
          ),
          _buildSaveBar(c),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(ThemeProvider c) => PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: Container(
          decoration: BoxDecoration(
            color: c.surface,
            border: Border(bottom: BorderSide(color: c.border)),
          ),
          child: SafeArea(
            child: Row(
              children: [
                IconButton(
                  icon: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: c.violet.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.arrow_back_rounded,
                        color: c.violet, size: 20),
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [c.violet, c.pink],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.auto_awesome_rounded,
                      color: Colors.white, size: 18),
                ),
                const SizedBox(width: 12),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Avatar Studio',
                      style: TextStyle(
                        color: c.textHigh,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      'Customize your style',
                      style: TextStyle(
                        color: c.violet.withOpacity(0.7),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );

  Widget _buildHeroSection(ThemeProvider c) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 24),
      decoration: BoxDecoration(
        color: c.surface,
        border: Border(bottom: BorderSide(color: c.border)),
      ),
      child: Column(
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 140,
                height: 140,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [c.violet, c.pink],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: c.violet.withOpacity(0.3),
                      blurRadius: 30,
                      spreadRadius: 5,
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () => _pickPhoto(ImageSource.gallery),
                child: AvatarWidget(config: _config, size: 126),
              ),
              Positioned(
                bottom: 4,
                right: 4,
                child: GestureDetector(
                  onTap: () => _showPhotoPicker(c),
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [c.violet, c.pink],
                      ),
                      shape: BoxShape.circle,
                      border: Border.all(color: c.surface, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: c.violet.withOpacity(0.4),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                    child: Icon(
                      _config.hasPhoto
                          ? Icons.edit_rounded
                          : Icons.camera_alt_rounded,
                      size: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              if (_picking)
                Container(
                  width: 126,
                  height: 126,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black.withOpacity(0.5),
                  ),
                  child: const Center(
                    child: CircularProgressIndicator(color: Colors.white),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: () => _showPhotoPicker(c),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [c.violet, c.pink],
                ),
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: c.violet.withOpacity(0.3),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    _config.hasPhoto
                        ? Icons.swap_horiz_rounded
                        : Icons.add_a_photo_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _config.hasPhoto ? 'Change Photo' : 'Upload Photo',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showPhotoPicker(ThemeProvider c) {
    showModalBottomSheet(
      context: context,
      backgroundColor: c.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Choose Photo',
                style: TextStyle(
                  color: c.textHigh,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: _photoSourceButton(
                      c,
                      '📷',
                      'Camera',
                      () {
                        Navigator.pop(context);
                        _pickPhoto(ImageSource.camera);
                      },
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _photoSourceButton(
                      c,
                      '🖼️',
                      'Gallery',
                      () {
                        Navigator.pop(context);
                        _pickPhoto(ImageSource.gallery);
                      },
                    ),
                  ),
                ],
              ),
              if (_config.hasPhoto) ...[
                const SizedBox(height: 16),
                TextButton.icon(
                  onPressed: () {
                    Navigator.pop(context);
                    setState(
                        () => _config = _config.copyWith(clearPhoto: true));
                  },
                  icon: const Icon(Icons.delete_outline_rounded,
                      color: Colors.red),
                  label: const Text('Remove Photo',
                      style: TextStyle(color: Colors.red)),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _photoSourceButton(
      ThemeProvider c, String emoji, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          color: c.elevated,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: c.border),
        ),
        child: Column(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 32)),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: c.textHigh,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSaveBar(ThemeProvider c) => Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        decoration: BoxDecoration(
          color: c.surface,
          border: Border(top: BorderSide(color: c.border)),
        ),
        child: SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _saving ? null : _save,
            style: ElevatedButton.styleFrom(
              backgroundColor: c.violet,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              elevation: 0,
            ),
            child: _saving
                ? const SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2.5),
                  )
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.check_circle_rounded, size: 20),
                      SizedBox(width: 10),
                      Text('Save Avatar',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700)),
                    ],
                  ),
          ),
        ),
      );
}

// ─── Filter Tab ────────────────────────────────────────────────
class _FilterTab extends StatelessWidget {
  final AvatarConfig config;
  final ValueChanged<AvatarConfig> onChanged;
  const _FilterTab({required this.config, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final c = Provider.of<ThemeProvider>(context);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [c.violet.withOpacity(0.1), c.pink.withOpacity(0.05)],
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: c.violet.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.filter_vintage_rounded, size: 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Artistic Filters',
                      style: TextStyle(
                        color: c.textHigh,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      'Transform your photo into art',
                      style: TextStyle(color: c.textMid, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.6,
          ),
          itemCount: enhancedFilters.length,
          itemBuilder: (_, i) {
            final f = enhancedFilters[i];
            final sel = config.filterIndex == f['index'];
            return GestureDetector(
              onTap: () =>
                  onChanged(config.copyWith(filterIndex: f['index'] as int)),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  gradient: sel
                      ? LinearGradient(
                          colors: [c.violet, c.pink],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : null,
                  color: sel ? null : c.elevated,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: sel ? Colors.transparent : c.border,
                    width: 1,
                  ),
                  boxShadow: sel
                      ? [
                          BoxShadow(
                            color: c.violet.withOpacity(0.3),
                            blurRadius: 12,
                          ),
                        ]
                      : null,
                ),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Center(
                          child: Text(f['emoji'] as String,
                              style: const TextStyle(fontSize: 24)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              f['name'] as String,
                              style: TextStyle(
                                color: sel ? Colors.white : c.textHigh,
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              f['desc'] as String,
                              style: TextStyle(
                                color: sel ? Colors.white70 : c.textMid,
                                fontSize: 10,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (sel)
                        const Icon(Icons.check_circle_rounded,
                            color: Colors.white, size: 20),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

// ─── Frame Tab ────────────────────────────────────────────────
// ─── Frame Tab with NONE option ────────────────────────────────────────
class _FrameTab extends StatelessWidget {
  final AvatarConfig config;
  final ValueChanged<AvatarConfig> onChanged;
  const _FrameTab({required this.config, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final c = Provider.of<ThemeProvider>(context);
    // Add "None" as first option with style = -1
    final frameOptions = [
      {'name': 'None', 'style': -1, 'icon': Icons.remove_circle_outline},
      {'name': 'Classic', 'style': 0, 'icon': Icons.circle_outlined},
      {'name': 'Glow', 'style': 1, 'icon': Icons.circle},
      {'name': 'Dashed', 'style': 2, 'icon': Icons.border_all_rounded},
      {'name': 'Star', 'style': 3, 'icon': Icons.star_outline},
      {'name': 'Double', 'style': 4, 'icon': Icons.ring_volume_rounded},
      {'name': 'Gradient', 'style': 5, 'icon': Icons.gradient_rounded},
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [c.cyan.withOpacity(0.1), c.violet.withOpacity(0.05)],
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: c.cyan.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.circle_outlined, size: 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Decorative Frames',
                      style: TextStyle(
                        color: c.textHigh,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      'Choose a frame style (None = no frame)',
                      style: TextStyle(color: c.textMid, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.0,
          ),
          itemCount: frameOptions.length,
          itemBuilder: (_, i) {
            final frame = frameOptions[i];
            final sel = config.frameStyle == frame['style'];
            final badge = Color(int.parse(
                'FF${config.badgeColor.replaceAll('#', '')}',
                radix: 16));

            return GestureDetector(
              onTap: () =>
                  onChanged(config.copyWith(frameStyle: frame['style'] as int)),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  gradient: sel
                      ? LinearGradient(
                          colors: [c.violet, c.pink],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : null,
                  color: sel ? null : c.elevated,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: sel ? Colors.transparent : c.border,
                    width: 1,
                  ),
                  boxShadow: sel
                      ? [
                          BoxShadow(
                            color: c.violet.withOpacity(0.3),
                            blurRadius: 12,
                          ),
                        ]
                      : null,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (frame['style'] == -1)
                      // Special display for "None" option
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: c.elevated,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: sel ? Colors.white : c.border,
                            width: 1.5,
                          ),
                        ),
                        child: Icon(
                          Icons.clear_rounded,
                          color: sel ? Colors.white : c.textMid,
                          size: 28,
                        ),
                      )
                    else
                      CustomPaint(
                        painter: AvatarFramePainter(
                            frameStyle: frame['style'] as int,
                            badgeColor: badge),
                        size: const Size(56, 56),
                      ),
                    const SizedBox(height: 10),
                    Text(
                      frame['name'] as String,
                      style: TextStyle(
                        color: sel ? Colors.white : c.textHigh,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

// ─── Colors Tab ───────────────────────────────────────────────
class _ColorsTab extends StatelessWidget {
  final AvatarConfig config;
  final ValueChanged<AvatarConfig> onChanged;
  const _ColorsTab({required this.config, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final c = Provider.of<ThemeProvider>(context);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildColorSection(
          c,
          'Background Colors',
          'Choose backdrop for avatar',
          premiumBackgrounds,
          config.bgColor,
          (col) => onChanged(config.copyWith(bgColor: col)),
        ),
        const SizedBox(height: 24),
        _buildColorSection(
          c,
          'Accent Colors',
          'Frame & ring color',
          premiumAccents,
          config.badgeColor,
          (col) => onChanged(config.copyWith(badgeColor: col)),
        ),
      ],
    );
  }

  Widget _buildColorSection(
    ThemeProvider c,
    String title,
    String subtitle,
    List<Map<String, dynamic>> colors,
    String selected,
    ValueChanged<String> onTap,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: c.violet.withOpacity(0.05),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: c.violet.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child:
                    Icon(Icons.color_lens_rounded, color: c.violet, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: c.textHigh,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(color: c.textMid, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: colors.map((col) {
            final hex = col['hex'] as String;
            final name = col['name'] as String;
            final sel = hex == selected;
            final color =
                Color(int.parse('FF${hex.replaceAll('#', '')}', radix: 16));
            return GestureDetector(
              onTap: () => onTap(hex),
              child: Tooltip(
                message: name,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: sel ? Colors.white : Colors.transparent,
                      width: 3,
                    ),
                    boxShadow: sel
                        ? [
                            BoxShadow(
                              color: color.withOpacity(0.5),
                              blurRadius: 12,
                              spreadRadius: 2,
                            ),
                          ]
                        : null,
                  ),
                  child: sel
                      ? const Icon(Icons.check_rounded,
                          color: Colors.white, size: 20)
                      : null,
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}

// ─── Sticker Tab ──────────────────────────────────────────────
class _StickerTab extends StatelessWidget {
  final AvatarConfig config;
  final ValueChanged<AvatarConfig> onChanged;
  const _StickerTab({required this.config, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final c = Provider.of<ThemeProvider>(context);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFFF59E0B).withOpacity(0.1),
                const Color(0xFFF97316).withOpacity(0.05)
              ],
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFF59E0B).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.emoji_emotions_rounded, size: 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Decorative Stickers',
                      style: TextStyle(
                        color: c.textHigh,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      'Add flair to your avatar',
                      style: TextStyle(color: c.textMid, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.0,
          ),
          itemCount: enhancedStickers.length,
          itemBuilder: (_, i) {
            final sticker = enhancedStickers[i];
            final sel = config.sticker == i;
            return GestureDetector(
              onTap: () => onChanged(config.copyWith(sticker: i)),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                decoration: BoxDecoration(
                  gradient: sel
                      ? LinearGradient(
                          colors: [c.violet, c.pink],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : null,
                  color: sel ? null : c.elevated,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: sel ? Colors.transparent : c.border,
                    width: 1,
                  ),
                  boxShadow: sel
                      ? [
                          BoxShadow(
                            color: c.violet.withOpacity(0.3),
                            blurRadius: 12,
                          ),
                        ]
                      : null,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      sticker['emoji'] as String,
                      style: const TextStyle(fontSize: 36),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      sticker['name'] as String,
                      style: TextStyle(
                        color: sel ? Colors.white : c.textMid,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
