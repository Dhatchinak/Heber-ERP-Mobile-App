import 'dart:convert';
import 'dart:typed_data';

import 'package:bhc_erp/Student/theme_provider.dart';
import 'package:bhc_erp/Student/widgets/custom_drawer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─────────────────────────────────────────────────────────────────────────────
// MODELS
// ─────────────────────────────────────────────────────────────────────────────

class TuitionFeeRecord {
  final int semester;
  final String receiptNo;
  final DateTime paidDate;
  final double tuitionFee;
  final double courseFee;
  final double universityFee;
  final double libraryLabFee;
  final double maintenanceFee;
  final double developmentFee;
  final double others;
  final double total;
  final bool isPaid;

  const TuitionFeeRecord({
    required this.semester,
    required this.receiptNo,
    required this.paidDate,
    required this.tuitionFee,
    required this.courseFee,
    required this.universityFee,
    required this.libraryLabFee,
    required this.maintenanceFee,
    required this.developmentFee,
    required this.others,
    required this.total,
    required this.isPaid,
  });
}

class ExamFeeRecord {
  final int semester;
  final String refId;
  final String custRefNo;
  final DateTime paidDate;
  final double amount;
  final bool isPaid;
  final String status;

  const ExamFeeRecord({
    required this.semester,
    required this.refId,
    required this.custRefNo,
    required this.paidDate,
    required this.amount,
    required this.isPaid,
    required this.status,
  });
}

class StudentFeeInfo {
  final String name;
  final String rollNo;
  final String course; // program_name from API
  final String degreeType; // 'PG' or 'UG' from degree_type
  final String stream; // stream field from API
  final int totalSemesters;
  final List<TuitionFeeRecord> tuitionFees;
  final List<ExamFeeRecord> examFees;

  const StudentFeeInfo({
    required this.name,
    required this.rollNo,
    required this.course,
    required this.degreeType,
    required this.stream,
    required this.totalSemesters,
    required this.tuitionFees,
    required this.examFees,
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// DUMMY DATA BUILDER (real student info, dummy fee amounts)
// ─────────────────────────────────────────────────────────────────────────────

StudentFeeInfo _buildFeeInfo({
  required String name,
  required String rollNo,
  required String course,
  required String degreeType,
  required String stream,
}) {
  final isPG = degreeType.toUpperCase() == 'PG';
  final totalSems = isPG ? 4 : 6;
  // Dummy: 5 semesters paid regardless of UG/PG (adjust as needed)
  final paidCount = totalSems >= 5 ? 5 : totalSems - 1;

  final tuition = List.generate(totalSems, (i) {
    final sem = i + 1;
    final paid = sem <= paidCount;
    return TuitionFeeRecord(
      semester: sem,
      receiptNo: paid ? 'OL/SF_Adm/${2260 + sem * 31}' : '',
      paidDate: paid
          ? DateTime(2023 + ((sem - 1) ~/ 2), ((sem - 1) % 6) * 2 + 1, 15)
          : DateTime.now(),
      tuitionFee: isPG ? 1500.00 : 1200.00,
      courseFee: isPG ? 6000.00 : 4500.00,
      universityFee: 630.00,
      libraryLabFee: 200.00,
      maintenanceFee: isPG ? 750.00 : 600.00,
      developmentFee: isPG ? 2000.00 : 1500.00,
      others: isPG ? 15075.00 : 11870.00,
      total: isPG ? 26155.00 : 20500.00,
      isPaid: paid,
    );
  });

  final exam = List.generate(totalSems, (i) {
    final sem = i + 1;
    final paid = sem <= paidCount;
    return ExamFeeRecord(
      semester: sem,
      refId: paid ? 'EX${601111 + sem * 1111}' : '',
      custRefNo: paid ? 'EX${500999 + sem * 999}' : '',
      paidDate: paid
          ? DateTime(2023 + ((sem - 1) ~/ 2), ((sem - 1) % 6) * 2 + 2, 19)
          : DateTime.now(),
      amount: 1355.00,
      isPaid: paid,
      status: paid ? 'SUCCESS' : 'PENDING',
    );
  });

  return StudentFeeInfo(
    name: name,
    rollNo: rollNo,
    course: course,
    degreeType: degreeType,
    stream: stream,
    totalSemesters: totalSems,
    tuitionFees: tuition,
    examFees: exam,
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN SCREEN
// ─────────────────────────────────────────────────────────────────────────────

class FeesHistoryScreen extends StatefulWidget {
  final String rollNo;
  final String studentName;

  const FeesHistoryScreen({
    super.key,
    required this.rollNo,
    required this.studentName,
  });

  @override
  State<FeesHistoryScreen> createState() => _FeesHistoryScreenState();
}

class _FeesHistoryScreenState extends State<FeesHistoryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  StudentFeeInfo? _info;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _load();
  }

  Future<void> _load() async {
    try {
      // ── Fetch real student profile ──────────────────────────────────────
      final resp = await http.get(
        Uri.parse('https://apierp.bhc.edu.in/api/students/${widget.rollNo}'),
        headers: {
          'Referer': 'http://117.232.64.75',
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 10));

      String name = widget.studentName;
      String course = '';
      String degreeType = 'UG';
      String stream = 'UG';

      if (resp.statusCode == 200) {
        final body = jsonDecode(resp.body) as Map<String, dynamic>;
        final d = body['data'] as Map<String, dynamic>? ?? {};
        name = d['name'] as String? ?? widget.studentName;
        stream = d['stream'] as String? ?? 'UG';
        final ca = d['current_academic'] as Map<String, dynamic>? ?? {};
        course = ca['program_name'] as String? ?? '';
        degreeType = ca['degree_type'] as String? ?? stream;
      }

      // ── TODO: Replace dummy fee amounts with real API when available ────
      // final feeResp = await http.get(
      //   Uri.parse('https://apierp.bhc.edu.in/api/students/${widget.rollNo}/fees'),
      //   headers: {'Referer': 'http://117.232.64.75', 'Accept': 'application/json'},
      // );
      // parse feeResp and build StudentFeeInfo from real data

      await Future.delayed(const Duration(milliseconds: 300));

      setState(() {
        _info = _buildFeeInfo(
          name: name,
          rollNo: widget.rollNo,
          course: course.isNotEmpty ? course : widget.studentName,
          degreeType: degreeType,
          stream: stream,
        );
        _loading = false;
      });
    } catch (e) {
      // Fallback: use widget params + prefs
      final prefs = await SharedPreferences.getInstance();
      final stream = prefs.getString('stream') ?? 'UG';
      setState(() {
        _info = _buildFeeInfo(
          name: widget.studentName,
          rollNo: widget.rollNo,
          course: '',
          degreeType: stream,
          stream: stream,
        );
        _loading = false;
      });
    }
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = Provider.of<ThemeProvider>(context);
    return Scaffold(
      backgroundColor: c.bg,
      drawer: CustomDrawer(
        rollNo: widget.rollNo,
        studentName: widget.studentName,
        currentRoute: '/fees',
      ),
      body: _loading
          ? _buildLoader(c)
          : _error != null
              ? _buildError(c)
              : _buildMain(c),
    );
  }

  // ── LOADER ────────────────────────────────────────────────────────────────
  Widget _buildLoader(ThemeProvider c) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 44,
            height: 44,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              color: c.cyan,
            ),
          ),
          const SizedBox(height: 18),
          Text('Loading fee records…',
              style: TextStyle(color: c.textMid, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildError(ThemeProvider c) => Center(
        child: Text('Error: $_error',
            style: TextStyle(color: c.pink, fontSize: 13)),
      );

  // ── MAIN BODY ─────────────────────────────────────────────────────────────
  Widget _buildMain(ThemeProvider c) {
    final info = _info!;
    return NestedScrollView(
      headerSliverBuilder: (_, __) => [_buildSliverAppBar(c, info)],
      body: TabBarView(
        controller: _tab,
        children: [
          _TuitionTab(info: info),
          _ExamTab(info: info),
        ],
      ),
    );
  }

  // ── SLIVER APP BAR ────────────────────────────────────────────────────────
  Widget _buildSliverAppBar(ThemeProvider c, StudentFeeInfo info) {
    final isPG = info.degreeType.toUpperCase() == 'PG';
    final tPaid = info.tuitionFees.where((f) => f.isPaid).length;
    final ePaid = info.examFees.where((f) => f.isPaid).length;
    final totalPaid = info.tuitionFees
        .where((f) => f.isPaid)
        .fold<double>(0, (s, f) => s + f.total);

    return SliverAppBar(
      expandedHeight: 210,
      floating: false,
      pinned: true,
      backgroundColor: c.surface,
      elevation: 0,
      scrolledUnderElevation: 0,
      leading: Builder(
        builder: (ctx) => IconButton(
          icon: Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: c.elevated,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: c.border),
            ),
            child: Icon(Icons.menu_rounded, color: c.textHigh, size: 18),
          ),
          onPressed: () => Scaffold.of(ctx).openDrawer(),
        ),
      ),
      flexibleSpace: FlexibleSpaceBar(
        collapseMode: CollapseMode.pin,
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: c.bannerGradient,
            ),
            border: Border(bottom: BorderSide(color: c.border)),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 56, 20, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title row
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: c.cyan.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: c.cyan.withOpacity(0.3)),
                        ),
                        child: Icon(Icons.account_balance_wallet_rounded,
                            color: c.cyan, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Fee History',
                                style: TextStyle(
                                    color: c.textHigh,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -0.3)),
                            if (info.course.isNotEmpty)
                              Text(info.course,
                                  style: TextStyle(
                                      color: c.textMid, fontSize: 11.5),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis),
                          ],
                        ),
                      ),
                      // PG / UG badge
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: isPG
                              ? c.violet.withOpacity(0.12)
                              : c.cyan.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: isPG
                                  ? c.violet.withOpacity(0.4)
                                  : c.cyan.withOpacity(0.4)),
                        ),
                        child: Text(
                          isPG ? 'PG' : 'UG',
                          style: TextStyle(
                              color: isPG ? c.violet : c.cyan,
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // Stats row
                  Row(
                    children: [
                      _statChip(
                          c, '${info.totalSemesters}', 'SEMESTERS', c.cyan),
                      const SizedBox(width: 10),
                      _statChip(c, '$tPaid/${info.totalSemesters}',
                          'TUITION PAID', c.green),
                      const SizedBox(width: 10),
                      _statChip(c, '$ePaid/${info.totalSemesters}', 'EXAM PAID',
                          c.violet),
                    ],
                  ),
                  const SizedBox(height: 10),
                  // Total amount paid
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: c.green.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: c.green.withOpacity(0.25)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.currency_rupee_rounded,
                            color: c.green, size: 14),
                        const SizedBox(width: 4),
                        Text(
                          'Total Paid: ₹${_fmtAmount(totalPaid)}',
                          style: TextStyle(
                              color: c.green,
                              fontWeight: FontWeight.w700,
                              fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(48),
        child: Container(
          color: c.surface,
          child: TabBar(
            controller: _tab,
            indicatorColor: c.cyan,
            indicatorWeight: 2.5,
            indicatorSize: TabBarIndicatorSize.tab,
            labelColor: c.cyan,
            unselectedLabelColor: c.textMid,
            labelStyle:
                const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
            unselectedLabelStyle:
                const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
            tabs: const [
              Tab(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.school_rounded, size: 15),
                    SizedBox(width: 6),
                    Text('Tuition Fees'),
                  ],
                ),
              ),
              Tab(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.assignment_turned_in_rounded, size: 15),
                    SizedBox(width: 6),
                    Text('Exam Fees'),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statChip(ThemeProvider c, String val, String lbl, Color col) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
        decoration: BoxDecoration(
          color: col.withOpacity(0.08),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: col.withOpacity(0.2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(val,
                style: TextStyle(
                    color: col, fontWeight: FontWeight.w800, fontSize: 15)),
            Text(lbl,
                style: TextStyle(
                    color: c.textLow,
                    fontSize: 8.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5)),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// TUITION TAB
// ─────────────────────────────────────────────────────────────────────────────

class _TuitionTab extends StatelessWidget {
  final StudentFeeInfo info;
  const _TuitionTab({required this.info});

  @override
  Widget build(BuildContext context) {
    final c = Provider.of<ThemeProvider>(context);
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      itemCount: info.totalSemesters,
      itemBuilder: (_, i) =>
          _TuitionCard(record: info.tuitionFees[i], info: info),
    );
  }
}

class _TuitionCard extends StatefulWidget {
  final TuitionFeeRecord record;
  final StudentFeeInfo info;
  const _TuitionCard({required this.record, required this.info});

  @override
  State<_TuitionCard> createState() => _TuitionCardState();
}

class _TuitionCardState extends State<_TuitionCard>
    with SingleTickerProviderStateMixin {
  bool _expanded = false;
  bool _downloading = false;
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 260));
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.easeInOutCubic);
    // Auto-expand last paid
    if (widget.record.isPaid &&
        widget.record.semester ==
            widget.info.tuitionFees.where((f) => f.isPaid).last.semester) {
      _expanded = true;
      _ctrl.value = 1.0;
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _toggle() {
    if (!widget.record.isPaid) return;
    setState(() => _expanded = !_expanded);
    _expanded ? _ctrl.forward() : _ctrl.reverse();
  }

  @override
  Widget build(BuildContext context) {
    final c = Provider.of<ThemeProvider>(context);
    final r = widget.record;
    final dateFmt = DateFormat('dd MMM yyyy');
    final accentColor = r.isPaid ? c.green : c.amber;

    return GestureDetector(
      onTap: _toggle,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: c.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
              color: r.isPaid
                  ? c.green.withOpacity(_expanded ? 0.5 : 0.2)
                  : c.border),
          boxShadow: [
            BoxShadow(
              color: r.isPaid && _expanded
                  ? c.green.withOpacity(c.isDarkMode ? 0.08 : 0.04)
                  : Colors.transparent,
              blurRadius: 20,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            // ── HEADER ──────────────────────────────────────────────────
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                gradient: r.isPaid
                    ? LinearGradient(
                        colors: [
                          c.green.withOpacity(c.isDarkMode ? 0.08 : 0.05),
                          Colors.transparent,
                        ],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      )
                    : null,
                color: r.isPaid ? null : c.elevated,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: Radius.circular(_expanded ? 0 : 18),
                  bottomRight: Radius.circular(_expanded ? 0 : 18),
                ),
              ),
              child: Row(
                children: [
                  // Semester badge
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: accentColor.withOpacity(0.35)),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('${r.semester}',
                            style: TextStyle(
                                color: accentColor,
                                fontWeight: FontWeight.w900,
                                fontSize: 16,
                                height: 1)),
                        Text('SEM',
                            style: TextStyle(
                                color: accentColor.withOpacity(0.7),
                                fontSize: 7,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.5)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Semester ${r.semester}',
                          style: TextStyle(
                              color: c.textHigh,
                              fontWeight: FontWeight.w700,
                              fontSize: 15),
                        ),
                        const SizedBox(height: 3),
                        if (r.isPaid) ...[
                          Row(
                            children: [
                              Icon(Icons.check_circle_rounded,
                                  color: c.green, size: 12),
                              const SizedBox(width: 4),
                              Text(
                                'Paid on ${dateFmt.format(r.paidDate)}',
                                style:
                                    TextStyle(color: c.textMid, fontSize: 11.5),
                              ),
                            ],
                          ),
                        ] else
                          Row(
                            children: [
                              Icon(Icons.schedule_rounded,
                                  color: c.amber, size: 12),
                              const SizedBox(width: 4),
                              Text('Payment pending',
                                  style: TextStyle(
                                      color: c.amber, fontSize: 11.5)),
                            ],
                          ),
                      ],
                    ),
                  ),
                  // Right side
                  if (r.isPaid) ...[
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '₹${_fmtAmount(r.total)}',
                          style: TextStyle(
                              color: c.green,
                              fontWeight: FontWeight.w800,
                              fontSize: 15),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            // Download
                            _IconBtn(
                              icon: _downloading
                                  ? Icons.hourglass_top_rounded
                                  : Icons.download_rounded,
                              color: c.cyan,
                              onTap: _downloading ? null : () => _download(c),
                            ),
                            const SizedBox(width: 6),
                            // Expand toggle
                            AnimatedRotation(
                              turns: _expanded ? 0.5 : 0,
                              duration: const Duration(milliseconds: 260),
                              child: Icon(Icons.keyboard_arrow_down_rounded,
                                  color: c.textMid, size: 20),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ] else
                    _StatusBadge(label: 'PENDING', color: c.amber),
                ],
              ),
            ),

            // ── EXPANDED BODY ────────────────────────────────────────────
            SizeTransition(
              sizeFactor: _anim,
              child: Container(
                decoration: BoxDecoration(
                  border: Border(top: BorderSide(color: c.border)),
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(18),
                    bottomRight: Radius.circular(18),
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      // Receipt no
                      _DetailRow(
                        icon: Icons.receipt_long_rounded,
                        label: 'Receipt No',
                        value: r.receiptNo,
                        valueColor: c.cyan,
                      ),
                      Divider(color: c.border, height: 20, thickness: 0.8),
                      // Fee breakdown
                      _AmtRow('Tuition Fee', r.tuitionFee, c),
                      _AmtRow('Course Fee', r.courseFee, c),
                      _AmtRow('University Fee', r.universityFee, c),
                      _AmtRow('Library CD / Lab CD', r.libraryLabFee, c),
                      _AmtRow('Maintenance Fee', r.maintenanceFee, c),
                      _AmtRow('Development Fee', r.developmentFee, c),
                      _AmtRow('Others', r.others, c),
                      Divider(color: c.borderBright, height: 20, thickness: 1),
                      // Total
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: c.green.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: c.green.withOpacity(0.25)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Total Fees Paid',
                                style: TextStyle(
                                    color: c.textHigh,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13)),
                            Text('₹${_fmtAmount(r.total)}',
                                style: TextStyle(
                                    color: c.green,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 15)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _download(ThemeProvider c) async {
    setState(() => _downloading = true);
    try {
      final r = widget.record;
      final info = widget.info;
      final bytes = await _genTuitionPdf(
        name: info.name,
        rollNo: info.rollNo,
        course: info.course,
        degreeType: info.degreeType,
        semester: r.semester,
        receiptNo: r.receiptNo,
        paidDate: DateFormat('dd-MMM-yyyy').format(r.paidDate),
        paidTime: DateFormat('h:mm:ssa').format(r.paidDate),
        tuitionFee: r.tuitionFee,
        courseFee: r.courseFee,
        universityFee: r.universityFee,
        libraryLabFee: r.libraryLabFee,
        maintenanceFee: r.maintenanceFee,
        developmentFee: r.developmentFee,
        others: r.others,
        total: r.total,
      );
      await Printing.sharePdf(
        bytes: bytes,
        filename: 'Fee_Receipt_Sem${r.semester}_${info.rollNo}.pdf',
      );
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// EXAM TAB
// ─────────────────────────────────────────────────────────────────────────────

class _ExamTab extends StatelessWidget {
  final StudentFeeInfo info;
  const _ExamTab({required this.info});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      itemCount: info.totalSemesters,
      itemBuilder: (_, i) => _ExamCard(record: info.examFees[i], info: info),
    );
  }
}

class _ExamCard extends StatefulWidget {
  final ExamFeeRecord record;
  final StudentFeeInfo info;
  const _ExamCard({required this.record, required this.info});

  @override
  State<_ExamCard> createState() => _ExamCardState();
}

class _ExamCardState extends State<_ExamCard>
    with SingleTickerProviderStateMixin {
  bool _expanded = false;
  bool _downloading = false;
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 260));
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.easeInOutCubic);
    if (widget.record.isPaid &&
        widget.record.semester ==
            widget.info.examFees.where((f) => f.isPaid).last.semester) {
      _expanded = true;
      _ctrl.value = 1.0;
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _toggle() {
    if (!widget.record.isPaid) return;
    setState(() => _expanded = !_expanded);
    _expanded ? _ctrl.forward() : _ctrl.reverse();
  }

  @override
  Widget build(BuildContext context) {
    final c = Provider.of<ThemeProvider>(context);
    final r = widget.record;
    final dateFmt = DateFormat('dd MMM yyyy, hh:mm a');
    final accentColor = r.isPaid ? c.violet : c.amber;

    return GestureDetector(
      onTap: _toggle,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: c.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
              color: r.isPaid
                  ? c.violet.withOpacity(_expanded ? 0.45 : 0.2)
                  : c.border),
          boxShadow: [
            BoxShadow(
              color: r.isPaid && _expanded
                  ? c.violet.withOpacity(c.isDarkMode ? 0.08 : 0.04)
                  : Colors.transparent,
              blurRadius: 20,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                gradient: r.isPaid
                    ? LinearGradient(
                        colors: [
                          c.violet.withOpacity(c.isDarkMode ? 0.08 : 0.05),
                          Colors.transparent,
                        ],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      )
                    : null,
                color: r.isPaid ? null : c.elevated,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: Radius.circular(_expanded ? 0 : 18),
                  bottomRight: Radius.circular(_expanded ? 0 : 18),
                ),
              ),
              child: Row(
                children: [
                  // Badge
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: accentColor.withOpacity(0.35)),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('${r.semester}',
                            style: TextStyle(
                                color: accentColor,
                                fontWeight: FontWeight.w900,
                                fontSize: 16,
                                height: 1)),
                        Text('SEM',
                            style: TextStyle(
                                color: accentColor.withOpacity(0.7),
                                fontSize: 7,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.5)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Semester ${r.semester} — Exam',
                            style: TextStyle(
                                color: c.textHigh,
                                fontWeight: FontWeight.w700,
                                fontSize: 15)),
                        const SizedBox(height: 3),
                        if (r.isPaid)
                          Row(
                            children: [
                              Icon(Icons.check_circle_rounded,
                                  color: c.violet, size: 12),
                              const SizedBox(width: 4),
                              Text(dateFmt.format(r.paidDate),
                                  style: TextStyle(
                                      color: c.textMid, fontSize: 11)),
                            ],
                          )
                        else
                          Row(
                            children: [
                              Icon(Icons.schedule_rounded,
                                  color: c.amber, size: 12),
                              const SizedBox(width: 4),
                              Text('Payment pending',
                                  style: TextStyle(
                                      color: c.amber, fontSize: 11.5)),
                            ],
                          ),
                      ],
                    ),
                  ),
                  if (r.isPaid) ...[
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('₹${_fmtAmount(r.amount)}',
                            style: TextStyle(
                                color: c.violet,
                                fontWeight: FontWeight.w800,
                                fontSize: 15)),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            _IconBtn(
                              icon: _downloading
                                  ? Icons.hourglass_top_rounded
                                  : Icons.download_rounded,
                              color: c.violet,
                              onTap: _downloading ? null : () => _download(c),
                            ),
                            const SizedBox(width: 6),
                            AnimatedRotation(
                              turns: _expanded ? 0.5 : 0,
                              duration: const Duration(milliseconds: 260),
                              child: Icon(Icons.keyboard_arrow_down_rounded,
                                  color: c.textMid, size: 20),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ] else
                    _StatusBadge(label: 'PENDING', color: c.amber),
                ],
              ),
            ),

            // Expanded body
            SizeTransition(
              sizeFactor: _anim,
              child: Container(
                decoration: BoxDecoration(
                  border: Border(top: BorderSide(color: c.border)),
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(18),
                    bottomRight: Radius.circular(18),
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _DetailRow(
                          icon: Icons.tag_rounded,
                          label: 'Ref. ID',
                          value: r.refId,
                          valueColor: c.violet),
                      const SizedBox(height: 8),
                      _DetailRow(
                          icon: Icons.confirmation_number_rounded,
                          label: 'Cust. Ref. No.',
                          value: r.custRefNo,
                          valueColor: c.cyan),
                      Divider(color: c.border, height: 20),
                      _AmtRow('Exam Fee Amount', r.amount, c),
                      const SizedBox(height: 8),
                      // Status pill
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Status',
                              style:
                                  TextStyle(color: c.textMid, fontSize: 12.5)),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 4),
                            decoration: BoxDecoration(
                              color: c.green.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(20),
                              border:
                                  Border.all(color: c.green.withOpacity(0.35)),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.check_circle_rounded,
                                    color: c.green, size: 12),
                                const SizedBox(width: 4),
                                Text(r.status,
                                    style: TextStyle(
                                        color: c.green,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 11)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _download(ThemeProvider c) async {
    setState(() => _downloading = true);
    try {
      final r = widget.record;
      final info = widget.info;
      final bytes = await _genExamPdf(
        name: info.name,
        rollNo: info.rollNo,
        course: info.course,
        semester: r.semester,
        refId: r.refId,
        custRefNo: r.custRefNo,
        paidDate: r.paidDate,
        amount: r.amount,
        status: r.status,
      );
      await Printing.sharePdf(
        bytes: bytes,
        filename: 'ExamFee_Sem${r.semester}_${info.rollNo}.pdf',
      );
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED SMALL WIDGETS
// ─────────────────────────────────────────────────────────────────────────────

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;
  const _IconBtn({required this.icon, required this.color, this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = Provider.of<ThemeProvider>(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Icon(icon, color: color, size: 15),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  const _StatusBadge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Text(label,
          style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8)),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color valueColor;
  const _DetailRow({
    required this.icon,
    required this.label,
    required this.value,
    required this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    final c = Provider.of<ThemeProvider>(context);
    return Row(
      children: [
        Container(
          width: 28,
          height: 28,
          decoration: BoxDecoration(
            color: valueColor.withOpacity(0.08),
            borderRadius: BorderRadius.circular(7),
          ),
          child: Icon(icon, color: valueColor, size: 14),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(label, style: TextStyle(color: c.textMid, fontSize: 12)),
        ),
        Text(value,
            style: TextStyle(
                color: valueColor, fontWeight: FontWeight.w700, fontSize: 12)),
      ],
    );
  }
}

Widget _AmtRow(String label, double amount, ThemeProvider c) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 3.5),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(color: c.textMid, fontSize: 12.5)),
        Text('₹${_fmtAmount(amount)}',
            style: TextStyle(
                color: c.textHigh,
                fontWeight: FontWeight.w600,
                fontSize: 12.5)),
      ],
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────

String _fmtAmount(double v) => NumberFormat('#,##,##0.00', 'en_IN').format(v);

// ─────────────────────────────────────────────────────────────────────────────
// PDF: TUITION — exact BHC format
// ─────────────────────────────────────────────────────────────────────────────

Future<Uint8List> _genTuitionPdf({
  required String name,
  required String rollNo,
  required String course,
  required String degreeType,
  required int semester,
  required String receiptNo,
  required String paidDate,
  required String paidTime,
  required double tuitionFee,
  required double courseFee,
  required double universityFee,
  required double libraryLabFee,
  required double maintenanceFee,
  required double developmentFee,
  required double others,
  required double total,
}) async {
  final doc = pw.Document();

  // Load logo from assets
  pw.ImageProvider? logo;
  try {
    final data = await rootBundle.load('assets/bhclogo.png');
    logo = pw.MemoryImage(data.buffer.asUint8List());
  } catch (_) {
    try {
      final data = await rootBundle.load('assets/logo.png');
      logo = pw.MemoryImage(data.buffer.asUint8List());
    } catch (_) {}
  }

  doc.addPage(pw.Page(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(36),
    build: (pw.Context ctx) {
      return pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          // ── OUTER BORDER BOX ──────────────────────────────────────────
          pw.Container(
            width: double.infinity,
            decoration: pw.BoxDecoration(
              border: pw.Border.all(color: PdfColors.black, width: 1.5),
            ),
            child: pw.Column(
              children: [
                // College header
                pw.Container(
                  padding: const pw.EdgeInsets.symmetric(
                      horizontal: 16, vertical: 12),
                  child: pw.Row(
                    crossAxisAlignment: pw.CrossAxisAlignment.center,
                    children: [
                      if (logo != null)
                        pw.Container(
                          width: 56,
                          height: 56,
                          child: pw.Image(logo),
                        ),
                      pw.SizedBox(width: 12),
                      pw.Expanded(
                        child: pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.center,
                          children: [
                            pw.Text(
                              'Bishop Heber College',
                              style: pw.TextStyle(
                                fontSize: 20,
                                fontWeight: pw.FontWeight.bold,
                              ),
                            ),
                            pw.Text(
                              '(Autonomous)',
                              style: pw.TextStyle(
                                  fontSize: 13, fontWeight: pw.FontWeight.bold),
                            ),
                            pw.SizedBox(height: 6),
                            pw.Text(
                              'Online Fee Receipt',
                              style: pw.TextStyle(
                                fontSize: 13,
                                fontWeight: pw.FontWeight.bold,
                                decoration: pw.TextDecoration.underline,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                // Divider
                pw.Divider(color: PdfColors.black, thickness: 1),
                // Student info rows
                pw.Padding(
                  padding: const pw.EdgeInsets.all(14),
                  child: pw.Row(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Expanded(
                        child: pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            _pRow('Roll No.', rollNo),
                            _pRow('Name', name),
                            _pRow('Class', course),
                            _pRow('Semester', '$semester'),
                          ],
                        ),
                      ),
                      // PG/UG badge top-right
                      pw.Container(
                        padding: const pw.EdgeInsets.symmetric(
                            horizontal: 10, vertical: 5),
                        decoration: pw.BoxDecoration(
                          border: pw.Border.all(color: PdfColors.black),
                        ),
                        child: pw.Text(
                          degreeType.toUpperCase() == 'PG' ? 'PG' : 'UG',
                          style: pw.TextStyle(
                              fontSize: 16, fontWeight: pw.FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),
                // Divider
                pw.Divider(color: PdfColors.black, thickness: 1),
                // Fee Paid Details section
                pw.Padding(
                  padding: const pw.EdgeInsets.all(14),
                  child: pw.Column(
                    children: [
                      pw.Center(
                        child: pw.Text(
                          'Fee Paid Details',
                          style: pw.TextStyle(
                            fontSize: 13,
                            fontWeight: pw.FontWeight.bold,
                            decoration: pw.TextDecoration.underline,
                          ),
                        ),
                      ),
                      pw.SizedBox(height: 10),
                      pw.Center(
                        child: pw.Text(
                          paidDate,
                          style: pw.TextStyle(
                              fontSize: 18, fontWeight: pw.FontWeight.bold),
                        ),
                      ),
                      pw.SizedBox(height: 4),
                      pw.Center(
                        child: pw.Text(
                          '$receiptNo - ${_fmtAmount(total)}',
                          style: pw.TextStyle(
                              fontSize: 16, fontWeight: pw.FontWeight.bold),
                        ),
                      ),
                      pw.SizedBox(height: 4),
                      pw.Center(
                        child: pw.Text(
                          'Nil',
                          style: pw.TextStyle(
                              fontSize: 14, fontWeight: pw.FontWeight.bold),
                        ),
                      ),
                      pw.SizedBox(height: 16),
                      // Fee breakdown table
                      pw.Table(
                        columnWidths: {
                          0: const pw.FlexColumnWidth(3),
                          1: const pw.FlexColumnWidth(2),
                        },
                        children: [
                          _pTRow('Tuition Fee', _fmtAmount(tuitionFee)),
                          _pTRow('Course Fee', _fmtAmount(courseFee)),
                          _pTRow('University Fee', _fmtAmount(universityFee)),
                          _pTRow(
                              'Library CD/ Lab CD', _fmtAmount(libraryLabFee)),
                          _pTRow('Maintenance Fee', _fmtAmount(maintenanceFee)),
                          _pTRow('Development Fee', _fmtAmount(developmentFee)),
                          _pTRow('Others', _fmtAmount(others)),
                        ],
                      ),
                      pw.SizedBox(height: 6),
                      pw.Divider(color: PdfColors.black, thickness: 0.8),
                      // Total
                      pw.Row(
                        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                        children: [
                          pw.Text('Total Fees Paid',
                              style: pw.TextStyle(
                                  fontSize: 13,
                                  fontWeight: pw.FontWeight.bold)),
                          pw.Text(_fmtAmount(total),
                              style: pw.TextStyle(
                                  fontSize: 13,
                                  fontWeight: pw.FontWeight.bold)),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          pw.Spacer(),
          // Footer
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text(
                '${paidDate.replaceAll(' ', '-').replaceAll('May', '05').replaceAll('Jan', '01').replaceAll('Jun', '06').replaceAll('Nov', '11').replaceAll('Dec', '12')}',
                style:
                    const pw.TextStyle(fontSize: 9, color: PdfColors.grey600),
              ),
              pw.Text('1',
                  style: const pw.TextStyle(
                      fontSize: 9, color: PdfColors.grey600)),
              pw.Text('IT Support, BHC.   $paidTime',
                  style: const pw.TextStyle(
                      fontSize: 9, color: PdfColors.grey600)),
            ],
          ),
        ],
      );
    },
  ));

  return doc.save();
}

// ─────────────────────────────────────────────────────────────────────────────
// PDF: EXAM — exact BHC format
// ─────────────────────────────────────────────────────────────────────────────

Future<Uint8List> _genExamPdf({
  required String name,
  required String rollNo,
  required String course,
  required int semester,
  required String refId,
  required String custRefNo,
  required DateTime paidDate,
  required double amount,
  required String status,
}) async {
  final doc = pw.Document();
  final txDate = DateFormat('yyyy/MM/dd hh:mm:ss a').format(paidDate);
  final footerDate = DateFormat('dd-MMM-yyyy,hh:mm:ssa').format(paidDate);

  pw.ImageProvider? logo;
  try {
    final data = await rootBundle.load('assets/bhclogo.png');
    logo = pw.MemoryImage(data.buffer.asUint8List());
  } catch (_) {
    try {
      final data = await rootBundle.load('assets/logo.png');
      logo = pw.MemoryImage(data.buffer.asUint8List());
    } catch (_) {}
  }

  doc.addPage(pw.Page(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.all(40),
    build: (pw.Context ctx) {
      return pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.center,
        children: [
          // Header
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.center,
            children: [
              if (logo != null)
                pw.Container(width: 60, height: 60, child: pw.Image(logo)),
              pw.SizedBox(width: 14),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('BISHOP HEBER COLLEGE',
                      style: pw.TextStyle(
                          fontSize: 18, fontWeight: pw.FontWeight.bold)),
                  pw.Text('(Autonomous)',
                      style: pw.TextStyle(
                          fontSize: 13, fontWeight: pw.FontWeight.bold)),
                  pw.Text('Tiruchirappalli - 620017.',
                      style: const pw.TextStyle(
                          fontSize: 11, color: PdfColors.grey700)),
                ],
              ),
            ],
          ),
          pw.SizedBox(height: 22),
          pw.Text('ONLINE FEES RECEIPT',
              style:
                  pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 6),
          pw.Text('Exam Fees Transaction Status',
              style:
                  pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 22),
          // Table
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey500, width: 0.8),
            columnWidths: {
              0: const pw.FlexColumnWidth(2),
              1: const pw.FlexColumnWidth(3),
            },
            children: [
              _eTRow('NAME.', name),
              _eTRow('ROLL NO.', rollNo),
              _eTRow('COURSE', course),
              _eTRow('SEMESTER', '$semester'),
              _eTRow('REF. ID', refId),
              _eTRow('CUST. REF. NO.', custRefNo),
              _eTRow('AMOUNT', 'Rs.${amount.toStringAsFixed(0)}'),
              _eTRow('STATUS', status),
              _eTRow('TRANSACTION DATE', txDate),
            ],
          ),
          pw.Spacer(),
          // Footer
          pw.Divider(color: PdfColors.grey400),
          pw.Text(
            'IT SUPPORT, Bishop Heber College(Autonomous).',
            style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey600),
          ),
          pw.SizedBox(height: 3),
          pw.Text(
            footerDate,
            style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey600),
          ),
        ],
      );
    },
  ));

  return doc.save();
}

// ─── PDF helpers ─────────────────────────────────────────────────────────────

pw.Widget _pRow(String label, String val) {
  return pw.Padding(
    padding: const pw.EdgeInsets.symmetric(vertical: 2.5),
    child: pw.Row(
      children: [
        pw.SizedBox(
            width: 80,
            child:
                pw.Text(': $label', style: const pw.TextStyle(fontSize: 11))),
        pw.Text(': $val',
            style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold)),
      ],
    ),
  );
}

pw.TableRow _pTRow(String label, String val) {
  return pw.TableRow(children: [
    pw.Padding(
      padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 5),
      child: pw.Text(label, style: const pw.TextStyle(fontSize: 11.5)),
    ),
    pw.Padding(
      padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 5),
      child: pw.Text(val,
          textAlign: pw.TextAlign.right,
          style: pw.TextStyle(fontSize: 11.5, fontWeight: pw.FontWeight.bold)),
    ),
  ]);
}

pw.TableRow _eTRow(String label, String val) {
  return pw.TableRow(children: [
    pw.Padding(
      padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: pw.Text(label,
          style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 11)),
    ),
    pw.Padding(
      padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: pw.Text(val,
          style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 11)),
    ),
  ]);
}
